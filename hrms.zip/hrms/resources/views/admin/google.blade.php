@include('admin.sidenav');
<section class="home-section" style="width: calc(100% - 58px);overflow:scroll">
        <div class="home-content" style="display:block;font-color:">
        <div class="panel">
            <h1  style=" text-align: left;">Google Map</h1><br>
            <hr><br>
    	
        <div class="panel">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1613.764202688277!2d121.27773340962594!3d13.151342593814645!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33bcbdecc84051a3%3A0xfc4e0b5017e7bf54!2sGreen%20Park%20Memorial%20Garden%20Cemetery!5e1!3m2!1sen!2sph!4v1717309963780!5m2!1sen!2sph" 
        style="border:0;" 
        allowfullscreen="" 
        loading="lazy" 
        referrerpolicy="no-referrer-when-downgrade"></iframe>

        </div>

        </div>
        </div>
      </section>
      <script src="/js/scripts.js"></script>
</body>
