@include('admin.sidenav');
<section class="home-section" style="width: calc(100% - 58px);overflow:scroll">
        <div class="home-content" style="display:block;font-color:">
        <div class="panel">
            <h1  style=" text-align: left;">Clients</h1><br>
            <hr><br>
            <div class="box">
                <p>no content</p>
           </div>
        </div>
        
        </div>
        </div>
      </section>
      <script src="/js/scripts.js"></script>
</body>