<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h1>Hello from Laravel!</h1>
    <p>This is a test email sent from your Laravel application using Gmail SMTP.</p>
</body>
</html>
