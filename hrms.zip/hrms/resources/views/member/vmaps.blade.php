@include('user.sidenav');
<section class="home-section" style="width: calc(100% - 58px);overflow:scroll">
        <div class="home-content" style="display:block;font-color:">
        <div class="panel">
            <h1  style=" text-align: left;">Virtual Map</h1><br>
            <hr><br>
        </div>

        </div>
        </div>
      </section>
        <script
        src="https://www.chatbase.co/embed.min.js"
        chatbotId="XJrq5XGGemsfY5X_30vHq"
        domain="www.chatbase.co"
        defer>
        </script>
      <script src="/js/scripts.js"></script>
</body>