@include('user.sidenav');
<section class="home-section" style="width: calc(100% - 58px);overflow:scroll">
        <div class="home-content" style="display:block;font-color:">
        <div class="panel">
            <h1  style=" text-align: left;">Notification</h1><br>
            <hr><br>
    	
        <div class="panel"style="display:flex; text-align:left;">
           <div class="notification-list-container">
        <div class="notification-list">
            <div class="notification-item">
                <p>Your <span class="type">appointment</span> has been successfully <span class="status">booked</span>.</p>
            </div>
        </div>
        </div>
        </div>

        </div>

        </div>
        </div>
      </section>
      <script
        src="https://www.chatbase.co/embed.min.js"
        chatbotId="XJrq5XGGemsfY5X_30vHq"
        domain="www.chatbase.co"
        defer>
        </script>
      <script src="/js/scripts.js"></script>
</body>
