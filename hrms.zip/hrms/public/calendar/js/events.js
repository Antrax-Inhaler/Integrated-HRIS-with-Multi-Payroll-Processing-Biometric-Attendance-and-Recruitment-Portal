var events = function() {
  return [{
  id: 1,
  title: "Mommy Bday.",
  start: "2019-01-05T14:30:00.000Z",
  end: null
  },
  {
  id: 2,
  title: "Surprise at Work!",
  start: "2019-01-10T16:30:00.000Z",
  end: null
  },
  {
  id: 3,
  title: "Study",
  start: "2019-01-25T21:30:00.000Z",
  end: null
  }
];
}
