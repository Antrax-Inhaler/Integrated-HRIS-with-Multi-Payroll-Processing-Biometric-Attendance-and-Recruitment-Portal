<?php echo $__env->make('admin.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="home-section" style="width: calc(100% - 58px); overflow:scroll">

    <div class="container mt-5">
        <h2>Member Deductions Management</h2>

        <!-- Button to trigger add deduction modal -->
        <button class="btn btn-success mb-3" data-toggle="modal" data-target="#addDeductionModal">Add Deduction</button>

        <!-- Deductions Table -->
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Member Name</th>
                <th>Deduction</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Effective Date</th>
                <th>Actions</th>
            </tr>
            </thead>
            <pjp tbody>
            <?php $__currentLoopData = $deductions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deduction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($deduction->id); ?></td>
                    <td><?php echo e($deduction->member->given_name); ?> <?php echo e($deduction->member->surname); ?></td>
                    <td><?php echo e($deduction->deduction_name); ?></td>
                    <td>
                        <?php switch($deduction->type):
                            case (1): ?>
                                Monthly
                                <?php break; ?>
                            <?php case (2): ?>
                                Semi-Monthly
                                <?php break; ?>
                            <?php case (3): ?>
                                Once
                                <?php break; ?>
                            <?php default: ?>
                                Unknown
                        <?php endswitch; ?>
                    </td>
                    <td><?php echo e($deduction->amount); ?></td>
                    <td><?php echo e($deduction->effective_date); ?></td>
                                        <td>
                        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editDeductionModal<?php echo e($deduction->id); ?>">Edit</button>
                        <form action="<?php echo e(route('admin.member-deductions.destroy', $deduction->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>

                <!-- Edit Deduction Modal -->
                <div class="modal fade" id="editDeductionModal<?php echo e($deduction->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editDeductionModalLabel<?php echo e($deduction->id); ?>" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editDeductionModalLabel<?php echo e($deduction->id); ?>">Edit Deduction</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('admin.member-deductions.update', $deduction->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="form-group">
                                        <label for="member_id">Member</label>
                                        <select class="form-control" name="member_id" required>
                                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($member->id); ?>" <?php echo e($deduction->member_id == $member->id ? 'selected' : ''); ?>><?php echo e($member->given_name); ?> <?php echo e($member->surname); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="deduction_id">Deduction</label>
                                        <select class="form-control" name="deduction_id" required>
                                            <?php $__currentLoopData = $deductionsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($d->id); ?>" <?php echo e($deduction->deduction_id == $d->id ? 'selected' : ''); ?>><?php echo e($d->deduction_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="type">Type</label>
                                        <select class="form-control" name="type" required>
                                            <option value="1" <?php echo e($deduction->type == 1 ? 'selected' : ''); ?>>Monthly</option>
                                            <option value="2" <?php echo e($deduction->type == 2 ? 'selected' : ''); ?>>Semi-Monthly</option>
                                            <option value="3" <?php echo e($deduction->type == 3 ? 'selected' : ''); ?>>Once</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="amount">Amount</label>
                                        <input type="number" class="form-control" name="amount" value="<?php echo e($deduction->amount); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="effective_date">Effective Date</label>
                                        <input type="date" class="form-control" name="effective_date" value="<?php echo e($deduction->effective_date ? \Carbon\Carbon::parse($deduction->effective_date)->format('Y-m-d') : ''); ?>">
                                    </div>
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Add Deduction Modal -->
    <div class="modal fade" id="addDeductionModal" tabindex="-1" role="dialog" aria-labelledby="addDeductionModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addDeductionModalLabel">Add Deduction</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.member-deductions.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="member_id">Member</label>
                            <select class="form-control" name="member_id" required>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($member->id); ?>"><?php echo e($member->given_name); ?> <?php echo e($member->surname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="deduction_id">Deduction</label>
                            <select class="form-control" name="deduction_id" required>
                                <?php $__currentLoopData = $deductionsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($d->id); ?>"><?php echo e($d->deduction_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="type">Type</label>
                            <select class="form-control" name="type" required>
                                <option value="1">Monthly</option>
                                <option value="2">Semi-Monthly</option>
                                <option value="3">Once</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input type="number" class="form-control" name="amount" required>
                        </div>
                        <div class="form-group">
                            <label for="effective_date">Effective Date</label>
                            <input type="date" class="form-control" name="effective_date">
                        </div>
                        <button type="submit" class="btn btn-success">Add Deduction</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/member-deduction.blade.php ENDPATH**/ ?>