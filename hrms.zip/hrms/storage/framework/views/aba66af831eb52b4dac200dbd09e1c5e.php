<?php echo $__env->make('applicant.psdtopbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h1 class="page-title">Voluntary Work</h1>
    <table class="voluntary-work-table">
        <thead>
            <tr>
                <th>Organization Name</th>
                <th>Address</th>
                <th>Position/Nature of Work</th>
                <th>From Date</th>
                <th>To Date</th>
                <th>Hours Worked</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $voluntaryWorks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($work->organization_name); ?></td>
                    <td><?php echo e($work->organization_address); ?></td>
                    <td><?php echo e($work->position_nature_of_work); ?></td>
                    <td><?php echo e($work->inclusive_dates_from); ?></td>
                    <td><?php echo e($work->inclusive_dates_to); ?></td>
                    <td><?php echo e($work->number_of_hours); ?></td>
                    <td>
                        <a href="<?php echo e(route('applicant.voluntarywork', ['edit' => $work->id])); ?>" class="update-button"><i class="fas fa-edit"></i> </a>
                        <form action="<?php echo e(route('applicant.voluntarywork.delete', $work->id)); ?>" method="POST" class="inline-form" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-button"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </tbody>
    </table>
    <!-- Form to Add or Edit Voluntary Work Entries -->
    <h3 class="section-title"><?php echo e(isset($editWork) ? 'Edit Voluntary Work' : 'Add Voluntary Work'); ?></h3>
    <form action="<?php echo e(isset($editWork) ? route('applicant.voluntarywork.update', $editWork->id) : route('applicant.voluntarywork.store')); ?>" method="POST" class="form-container">
        <?php echo csrf_field(); ?>
        <?php if(isset($editWork)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="form-group">
            <label for="organization_name">Organization Name:</label>
            <input type="text" id="organization_name" name="organization_name" value="<?php echo e($editWork->organization_name ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="organization_address">Organization Address:</label>
            <input type="text" id="organization_address" name="organization_address" value="<?php echo e($editWork->organization_address ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="position_nature_of_work">Position/Nature of Work:</label>
            <input type="text" id="position_nature_of_work" name="position_nature_of_work" value="<?php echo e($editWork->position_nature_of_work ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="inclusive_dates_from">From Date:</label>
            <input type="date" id="inclusive_dates_from" name="inclusive_dates_from" value="<?php echo e($editWork->inclusive_dates_from ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="inclusive_dates_to">To Date:</label>
            <input type="date" id="inclusive_dates_to" name="inclusive_dates_to" value="<?php echo e($editWork->inclusive_dates_to ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="number_of_hours">Number of Hours:</label>
            <input type="number" id="number_of_hours" name="number_of_hours" value="<?php echo e($editWork->number_of_hours ?? ''); ?>" required>
        </div>

        <button type="submit" class="submit-button"><?php echo e(isset($editWork) ? 'Update' : 'Add'); ?></button>
    </form>
    <br>
    <hr>
    <div class="navigation-buttons">
        <button id="back-button" class="nav-button" onclick="goBack()">Back</button>
        <button id="next-button" class="nav-button" onclick="goNext()">Next</button>
    </div>
    

</div>
<script>
    function goBack() {
        // Navigate to the specified back URL
        window.location.href = '/applicant/work-experience'; // Replace with the actual URL
    }
    
    function goNext() {
        // Navigate to the specified next URL
        window.location.href = '/applicant/learning-development'; // Replace with the actual URL
    }
    </script>
    
</html><?php /**PATH C:\xampp\htdocs\hrms\resources\views/applicant/voluntarywork.blade.php ENDPATH**/ ?>