<?php echo $__env->make('member.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="home-section" style="width: calc(100% - 58px); overflow: scroll">
    <h2>Additional Commissions</h2>

    <!-- Filter Form -->
    <form method="GET" action="<?php echo e(route('member.add_com')); ?>" class="mb-4">
        <div class="row">
            <div class="col-md-3">
                <label for="start_date">Start Date</label>
                <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
            </div>
            <div class="col-md-3">
                <label for="end_date">End Date</label>
                <input type="date" name="end_date" id="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
            </div>
            <div class="col-md-3">
                <label for="description">Description</label>
                <input type="text" name="description" id="description" class="form-control" placeholder="Search description" value="<?php echo e(request('description')); ?>">
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="<?php echo e(route('member.add_com')); ?>" class="btn btn-secondary ml-2">Clear</a>
            </div>
        </div>
    </form>

    <!-- Commissions Listing Table -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Amount</th>
                <th>Month & Year</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $commissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($commission->id); ?></td>
                    <td><?php echo e($commission->amount); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($commission->month_year)->format('F Y')); ?></td>
                    <td><?php echo e($commission->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</section>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/member/add_com.blade.php ENDPATH**/ ?>