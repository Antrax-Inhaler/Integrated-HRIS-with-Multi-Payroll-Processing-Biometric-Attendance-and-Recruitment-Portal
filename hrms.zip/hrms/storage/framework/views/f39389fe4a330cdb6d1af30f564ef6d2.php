<?php echo $__env->make('admin.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="home-section" style="width: calc(100% - 58px); overflow-x:scroll">

<div class="container">
    
    <h2>Upload Attendance File</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <!-- Display error messages -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Form for file upload -->
    <form action="<?php echo e(route('admin.upload.import')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="attendance_file">Choose Attendance File (Upload the file from the Exported Logs from Fingerprint Scannero)</label>
            <input type="file" class="form-control-file" id="attendance_file" name="attendance_file" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Upload</button>
    </form>

    <!-- Table for Latest Attendance -->
    <h3 class="mt-5">Latest Attendance Records</h3>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Member ID</th>
                <th>Log Type</th>
                <th>Date & Time</th>
                <th>Source</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $latestAttendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($attendance->member_id); ?></td>
                    <td><?php echo e($attendance->log_type); ?></td>
                    <td><?php echo e($attendance->datetime_log); ?></td>
                    <td><?php echo e($attendance->source); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
    <!-- Pagination for Latest Attendance -->
    <div class="pagination-container">
        <?php echo e($latestAttendance->links()); ?>

    </div>

    <!-- Table for All Attendance -->
    <h3 class="mt-5">All Attendance Records</h3>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Member ID</th>
                <th>Log Type</th>
                <th>Date & Time</th>
                <th>Source</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $allAttendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($attendance->member_id); ?></td>
                    <td><?php echo e($attendance->log_type); ?></td>
                    <td><?php echo e($attendance->datetime_log); ?></td>
                    <td><?php echo e($attendance->source); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Pagination for All Attendance -->
    <div class="pagination-container">
        <?php echo e($allAttendance->links()); ?>

    </div>

</div>

<style>
    .pagination-container {
        display: flex;
        justify-content: left;
        overflow: hidden; /* Hide overflow if necessary */
        width: 300px; /* Fixed width for the container */
        margin: 20px auto; /* Center the container with margin */
        height: 50px;
    }

    .pagination {
        display: flex;
    }

    .pagination a,
    .pagination span {
        margin: 0 5px;
        padding: 8px 12px;
        border: 1px solid #007bff; /* Change the border color */
        border-radius: 4px; /* Rounded corners */
        text-decoration: none;
        color: #007bff; /* Link color */
        font-weight: bold;
    }

    .pagination a:hover {
        background-color: #007bff; /* Background color on hover */
        color: white; /* Text color on hover */
    }

    .pagination .active {
        background-color: #007bff; /* Active page background color */
        color: white; /* Active page text color */
        border: 1px solid #007bff; /* Border to match */
    }
</style>
</section>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/upload.blade.php ENDPATH**/ ?>