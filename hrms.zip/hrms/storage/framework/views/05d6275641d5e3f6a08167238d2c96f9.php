
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        @page {
            margin: 0; /* Set margins to zero */
            width: 8.5in; 
            height: 13in; 
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 8pt;
        }
        .full-page-image {
            width: 8.5in; 
            height: 12in; 
            object-fit: cover; /* Ensures the image covers the entire area */
            position: absolute; /* Allows layering */
            top: 0; /* Align to the top */
            left: 0; /* Align to the left */
        }
        .page {
            position: relative; /* Required for absolute positioning of the image */
            width: 100%;
            height: 100%;
            page-break-after: always; /* Forces a page break after each section */
        }
        .personal-info {
            position: absolute; /* Allows you to position elements anywhere on the page */
            z-index: 1; /* Ensures the content is above the background image */
            color: rgb(0, 0, 0); /* Text color */
        }
                /* Personal Info Classes */
.personal-info.surname {
    top: 212px;
    left: 398px;
}

.personal-info.given-name {
    top: 212px;
    left: 529px;
}

.personal-info.middle-name {
    top: 212px;
    left: 645px;
}

.personal-info.position {
    top: 243px;
    left: 386px;
}

.personal-info.salary {
    top: 243px;
    left: 663px;
}

.personal-info.department {
    top: 243px;
    left: 178px;
}

/* Personal Info Classes */
.personal-info.vacation-leave {
    top: 328px;
    left: 67px;
}

.personal-info.mandatory-forced-leave {
    top: 351px;
    left: 67px;
}

.personal-info.sick-leave {
    top: 374px;
    left: 67px;
}

.personal-info.maternity-leave {
    top: 395px;
    left: 67px;
}

.personal-info.paternity-leave {
    top: 415px;
    left: 67px;
}

.personal-info.special-privilege-leave {
    top: 437px;
    left: 67px;
}

.personal-info.solo-parent-leave {
    top: 460px;
    left: 67px;
}

.personal-info.study-leave {
    top: 482px;
    left: 67px;
}

.personal-info.ten-day-vawc-leave {
    top: 503px;
    left: 67px;
}

.personal-info.rehabilitation-privilege {
    top: 525px;
    left: 67px;
}

.personal-info.special-leave-for-women {
    top: 547px;
    left: 67px;
}

.personal-info.special-emergency-calamity-leave {
    top: 569px;
    left: 67px;
}

.personal-info.adoption-leave {
    top: 591px;
    left: 67px;
}


.personal-info.others-type-of-leave {
    top: 658px;
    left: 67px;
}

.personal-info.within-philippines {
    top: 350px;
    left: 464px;
}

.personal-info.abroad {
    top: 372px;
    left: 463px;
}

.personal-info.abroad-specify {
    top: 372px;
    left: 572px;
}

.personal-info.in-hospital {
    top: 415px;
    left: 463px;
}

.personal-info.hospital-specify-illness {
    top: 415px;
    left: 627px;
}

.personal-info.outpatient {
    top: 437px;
    left: 463px;
}

.personal-info.outpatient-specify-illness {
    top: 437px;
    left: 633px;
}

.personal-info.special-leave-illness {
    top: 503px;
    left: 550px;
}

.personal-info.study-leave-completion-masters {
    top: 569px;
    left: 464px;
}

.personal-info.study-leave-bar-review {
    top: 591px;
    left: 464px;
}

.personal-info.monetization-of-leave-credits {
    top: 635px;
    left: 464px;
}

.personal-info.terminal-leave {
    top: 657px;
    left: 464px;
}

.personal-info.details-of-leave {
    top: 657px;
    left: 534px;
}

.personal-info.working-days-applied {
    top: 657px;
    left: 464px;
}

.personal-info.commutation-not-requested {
    top: 707px;
    left: 462px;
}
.personal-info.commutation-requested {
    top: 729px;
    left: 462px;
}

.personal-info.inclusive-dates {
    top: 749px;
    left: 78px;
}

.personal-info.total-earned-sick {
    top: 881px;
    left: 339px;
}

.personal-info.total-earned-vacation {
    top: 882px;
    left: 200px;
}

.personal-info.less-this-application-vacation {
    top: 899px;
    left: 200px;
}

.personal-info.less-this-application-sick {
    top: 899px;
    left: 339px;
}

.personal-info.balance-vacation {
    top: 913px;
    left: 200px;
}

.personal-info.balance-sick {
    top: 913px;
    left: 339px;
}

.personal-info.authorize-officer-credits {
    top: 950px;
    left: 126px;
}

.personal-info.approval-status {
    top: 843px;
    left: 463px;
}

.personal-info.for-disapproval {
    top: 866px;
    left: 463px;
}
.personal-info.disapproval-reason {
    top: 882px;
    left: 480px;
}
.personal-info.authorize-officer-recommendation {
    top: 949px;
    left: 509px;
}

.personal-info.approved-days-with-pay {
    top: 1015px;
    left: 85px;
}

.personal-info.approved-days-without-pay {
    top: 1030px;
    left: 85px;
}

.personal-info.approved-others {
    top: 1045px;
    left: 85px;
}

.personal-info.disapproved-due-to {
    top: 1015px;
    left: 481px;
}

.personal-info.authorized-official {
    top: 1120px;
    left: 342px;
}
    </style>
</head>
<body>

    <div class="page"> 
        <img src="<?php echo e($image1); ?>" class="full-page-image" alt="Background Image 1">
        <div class="personal-info surname"><?php echo e($personalInformation->surname); ?> </div>
<div class="personal-info given-name"><?php echo e($personalInformation->given_name); ?></div>
<div class="personal-info middle-name"><?php echo e($personalInformation->middle_name); ?></div>
<div class="personal-info position"><?php echo e($personalInformation->position); ?></div>
<div class="personal-info salary"><?php echo e($personalInformation->salary); ?></div>
<div class="personal-info department"><?php echo e($personalInformation->department); ?></div>
<div class="personal-info vacation-leave">
    <?php if($leave->vacation_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
        <span>&mdash;</span>
    <?php endif; ?>
</div>

<div class="personal-info mandatory-forced-leave">
    <?php if($leave->mandatory_forced_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info sick-leave">
    <?php if($leave->sick_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info maternity-leave">
    <?php if($leave->maternity_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info paternity-leave">
    <?php if($leave->paternity_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info special-privilege-leave">
    <?php if($leave->special_privilege_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info solo-parent-leave">
    <?php if($leave->solo_parent_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info study-leave">
    <?php if($leave->study_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info ten-day-vawc-leave">
    <?php if($leave->ten_day_vawc_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info rehabilitation-privilege">
    <?php if($leave->rehabilitation_privilege): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info special-leave-for-women">
    <?php if($leave->special_leave_for_women): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info special-emergency-calamity-leave">
    <?php if($leave->special_emergency_calamity_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>

<div class="personal-info adoption-leave">
    <?php if($leave->adoption_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>


<div class="personal-info others-type-of-leave">Others Type of Leave: <?php echo e($leave->others_type_of_leave); ?></div>
<div class="personal-info within-philippines">
    <?php if($leave->within_philippines): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>
<div class="personal-info abroad">
    <?php if($leave->abroad): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>
<div class="personal-info abroad-specify"> <?php echo e($leave->abroad_specify); ?></div>
<div class="personal-info in-hospital">
    <?php if($leave->in_hospital): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div><div class="personal-info hospital-specify-illness">Specify Illness in Hospital: <?php echo e($leave->hospital_specify_illness); ?></div>
<div class="personal-info outpatient">
    <?php if($leave->outpatient): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div><div class="personal-info outpatient-specify-illness">Specify Illness Outpatient: <?php echo e($leave->outpatient_specify_illness); ?></div>
<div class="personal-info special-leave-illness">Special Leave for Illness: <?php echo e($leave->special_leave_illness); ?></div>
<div class="personal-info study-leave-completion-masters">
    <?php if($leave->study_leave_completion_masters): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div><div class="personal-info study-leave-bar-review">
    <?php if($leave->study_leave_bar_review): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>
<div class="personal-info monetization-of-leave-credits">
    <?php if($leave->monetization_of_leave_credits): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>
<div class="personal-info terminal-leave">
    <?php if($leave->terminal_leave): ?>
        <span style="font-family:zapfdingbats;">3</span>
    <?php else: ?>
    <?php endif; ?>
</div>
<div class="personal-info details-of-leave">Details of Leave: <?php echo e($leave->details_of_leave); ?></div>
<div class="personal-info working-days-applied"> <?php echo e($leave->working_days_applied); ?></div>
<?php if($leave->commutation == 1): ?>
    <div class="personal-info commutation-requested">
        <span style="font-family:zapfdingbats;">3</span>
    </div>
<?php else: ?>
    <div class="personal-info commutation-not-requested">
        <span style="font-family:zapfdingbats;">3</span>
    </div>
<?php endif; ?>

<div class="personal-info inclusive-dates"><?php echo e($leave->inclusive_dates); ?></div>
<div class="personal-info total-earned-sick"> <?php echo e($leave->total_earned_sick); ?></div>
<div class="personal-info total-earned-vacation"> <?php echo e($leave->total_earned_vacation); ?></div>
<div class="personal-info less-this-application-vacation"> <?php echo e($leave->less_this_application_vacation); ?></div>
<div class="personal-info less-this-application-sick"><?php echo e($leave->less_this_application_sick); ?></div>
<div class="personal-info balance-vacation"><?php echo e($leave->balance_vacation); ?></div>
<div class="personal-info balance-sick"><?php echo e($leave->balance_sick); ?></div>
<div class="personal-info authorize-officer-credits"> <?php echo e($leave->authorize_officer_credits); ?></div>
<?php if($leave->approval_status == 'For approval'): ?>
    <div class="personal-info approval-status">
        <span style="font-family:zapfdingbats;">3</span>
    </div>
<?php elseif($leave->approval_status == 'For disapproval'): ?>
    <div class="personal-info for-disapproval">
        <span style="font-family:zapfdingbats;">3</span>
    </div>
<?php endif; ?>


<div class="personal-info disapproval-reason"><?php echo e($leave->disapproval_reason); ?></div>
<div class="personal-info authorize-officer-recommendation"><?php echo e($leave->authorize_officer_recommendation); ?></div>
<div class="personal-info approved-days-with-pay"><?php echo e($leave->approved_days_with_pay); ?></div>
<div class="personal-info approved-days-without-pay"> <?php echo e($leave->approved_days_without_pay); ?></div>
<div class="personal-info approved-others"><?php echo e($leave->approved_others); ?></div>
<div class="personal-info disapproved-due-to"> <?php echo e($leave->disapproved_due_to); ?></div>
<div class="personal-info authorized-official"><?php echo e($leave->authorized_official); ?></div>

    </div>
   
</body>
</html>
    
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/leavePDF.blade.php ENDPATH**/ ?>