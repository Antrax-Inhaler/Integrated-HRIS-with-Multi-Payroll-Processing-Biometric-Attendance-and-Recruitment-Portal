<!-- resources/views/admin/fingerprint.blade.php -->


<section class="home-section" style="width: calc(100% - 58px); overflow:scroll">
    <form action="<?php echo e(route('admin.fingerprint.import')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="file">Select Excel File</label>
            <input type="file" name="file" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Import Attendance</button>
    </form>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <!-- Display extracted attendance data -->
    <?php if(!empty($attendanceData)): ?>
        <h3>Imported Attendance Data</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Member ID</th>
                    <th>Date</th>
                    <th>AM IN</th>
                    <th>AM OUT</th>
                    <th>PM IN</th>
                    <th>PM OUT</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $attendanceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data['member_id']); ?></td>
                        <td><?php echo e($data['date']); ?></td>
                        <td><?php echo e($data['AM IN']); ?></td>
                        <td><?php echo e($data['AM OUT']); ?></td>
                        <td><?php echo e($data['PM IN']); ?></td>
                        <td><?php echo e($data['PM OUT']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    <?php if(is_array($errors) && count($errors) > 0): ?>
    <div class="alert error-alert">
        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php elseif($errors->any()): ?>
    <div class="alert error-alert">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

</section>

<?php echo $__env->make('admin.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/fingerprint.blade.php ENDPATH**/ ?>