<?php echo $__env->make('applicant.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.1/css/boxicons.min.css">


<style>
    .pds-button-view{
        text-decoration: underline;
        color: #333;
        background: none;
        border: none;
        padding: none;
    }
</style>
<div class="content">

    <div class="job-listings">
        <button class="pds-button" onclick="window.location.href='/applicant/'">
            <i class="fas fa-arrow-left"> Job List
        </button>
         <br>
        <div class="job-card">
            <div class="job-card-header">
                <div class="title-container">
                    <div class="job-title">
                        <i class="bx bxs-briefcase"></i> <?php echo e($job->job_title); ?>

                    </div>
                </div>
                <div class="job-type">
                    <span class="job-badge"><?php echo e($job->job_type); ?></span>
                </div>
            </div>
    
            <div class="job-details">
                <div class="detail-item">
                    <i class="bx bxs-building-house"></i>
                    <span>Department: </span><?php echo e($job->department); ?>

                </div>
                <div class="detail-item">
                    <i class="bx bxs-dollar-circle"></i>
                    <span>Salary Range: </span><?php echo e($job->salary_range); ?>

                </div>
                <div class="detail-item">
                    <i class="bx bxs-graduation"></i>
                    <span>Education Requirement: </span><?php echo e($job->education_requirement); ?>

                </div>
                <div class="detail-item">
                    <i class="bx bx-calendar-event"></i>
                    <span>Deadline: </span><?php echo e($job->application_deadline->format('jS F Y')); ?>

                </div>
                <div class="detail-item">
                    <i class="bx bx-calendar-check"></i>
                    <span>Posted: </span><?php echo e($job->posted_date->format('jS F Y')); ?>

                </div>
            </div>
            <div class="descriptio-container">
            <div class="job-description">
                <p><?php echo e(\Illuminate\Support\Str::limit($job->job_description, 150)); ?></p>
            </div>
        </div>
        <div class="requirements-container" style="margin-top: 20px;">
            <h3>Other Requirements</h3>
            <!-- Add this button in the applicant.apply view, after the job description -->
            <br>
            <li>
                Complete your Personal Data Sheet
                <div class="job-application-form" style="padding-top: 10px;">
                    <form method="GET" action="<?php echo e(route('apply.pdf')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="applicant_id" value="<?php echo e($applicantId); ?>">
                        <!-- PDF Button -->
                        <div class="form-group">
                            <button type="submit" class="pds-button-view">Your PDS</button>
                        </div>
                    </form>
                </div>
            </li>

            <?php if($job->requirements && $job->requirements->isNotEmpty()): ?>
                <ul>
                    <?php $__currentLoopData = $job->requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <strong><?php echo e($requirement->requirement_name); ?></strong>
                            <?php if($requirement->file_path): ?>
                                <br>
                                <a href="<?php echo e(asset($requirement->file_path)); ?>" target="_blank">View File</a>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p>No other requirements available in this job.</p>
            <?php endif; ?>
        </div>
        <li>
            <strong>
                
            </strong>
        </li>


        
        <div class="job-application-form" style="border-top: 1px solid #eee; padding-top: 20px;">
            <form method="POST" action="<?php echo e(route('job-applications.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="job_listing_id" value="<?php echo e($job->id); ?>">
                <input type="hidden" name="applicant_id" value="<?php echo e($applicantId); ?>">
        
                <div class="form-group">
                    <label for="requirements">Job Requirements</label>
                    <ul>
                        <?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($requirement->description); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
        
                <div class="form-group" style="text-align: right;">
                    <button type="submit" class="apply-button">Submit Application</button>
                </div>
            </form>
        </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/applicant/apply.blade.php ENDPATH**/ ?>