<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        @page {
            margin: 0; /* Set margins to zero */
            width: 8.5in; 
            height: 13in; 
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 8pt;
        }
        .full-page-image {
            width: 8.5in; 
            height: 13in; 
            object-fit: cover; /* Ensures the image covers the entire area */
            position: absolute; /* Allows layering */
            top: 0; /* Align to the top */
            left: 0; /* Align to the left */
        }
        .page {
            position: relative; /* Required for absolute positioning of the image */
            width: 100%;
            height: 100%;
            page-break-after: always; /* Forces a page break after each section */
        }
        .personal-info {
            position: absolute; /* Allows you to position elements anywhere on the page */
            z-index: 1; /* Ensures the content is above the background image */
            color: rgb(0, 0, 0); /* Text color */
            text-transform: uppercase;

        }
        .personal-info.surname {
    top: 340px;
    left: 250px;
}.personal-info.salary {
    top: 340px;
    left: 625px;
}

.personal-info.middle-name {
    top: 212px;
    left: 645px;
}


.department {
    top: 370px;
    left: 625px;
}

.departure-date {
    top: 387px;
    left: 250px;
}

.return-date {
    top: 387px;
    left: 625px;
}
.position{
    top: 372px;
    left: 250px;
}
.destination {
    top: 404px;
    left: 250px;
}

.specific-purpose {
    top: 436px;
    left: 250px;
}

.objectives {
    top: 497px;
    left: 250px;

}

.per-diem-expenses {
    top: 544px;
    left: 250px;
}

.assistant-or-laborers-allowed {
    top: 560px;
    left: 311px;
}

.appropriation-to-which-travel {
    top: 574px;
    left: 301px;
}

.should-be-charged {
    top: 596px;
    left: 451px;
}
.remarks-or-special-instructions {
    top: 614px;
    left: 308px;
}

.recommending-approval {
    top: 725px;
    left: 106px;
}

.approved-by {
    top: 725px;
    left: 516px;
}

.inclusive-dates {
    top: 610px;
    left: 20px;
}

.certifying-officers {
    top: 690px;
    left: 20px;
}

.immediate-supervisor {
    top: 822px;
    left: 202px;
}

.supervisor-designation {
    top: 791px;
    left: 158px;
}

.document-number {
    top: 1182px;
    left: 113px;
}

.revision-number {
    top: 1198px;
    left: 113px;
}

.issued-date {
    top: 1214px;
    left: 126px;
}
.travel-number{
    top: 273px;
    left: 625px;
}
.additional-date{
    top: 290px;
    left: 625px;
}
    </style>
</head>
<body>

    <div class="page"> 
        <img src="<?php echo e($image1); ?>" class="full-page-image" alt="Background Image 1">
        <div class="personal-info surname"> <?php echo e($personalInformation->surname); ?>, <?php echo e($personalInformation->given_name); ?> <?php echo e($personalInformation->middle_name); ?></div>

        <div class="personal-info position"><?php echo e($personalInformation->position); ?></div>
        <div class="personal-info salary"><?php echo e($personalInformation->salary); ?></div>
        <div class="personal-info department"><?php echo e($personalInformation->department); ?></div>

        <div class="personal-info additional-date"><?php echo e($travel->additional_date); ?></div>
        <div class="personal-info travel-number"><?php echo e($travel->travel_number); ?></div>
        <div class="personal-info departure-date"><?php echo e($travel->departure_date); ?></div>
        <div class="personal-info return-date"><?php echo e($travel->return_date); ?></div>
        <div class="personal-info destination"><?php echo e($travel->destination); ?></div>
        <div class="personal-info specific-purpose"><?php echo e($travel->specific_purpose); ?></div>
        <div class="personal-info objectives"><?php echo e($travel->objectives); ?></div>
        <div class="personal-info per-diem-expenses"><?php echo e($travel->per_diem_expenses); ?></div>
        <div class="personal-info assistant-or-laborers-allowed"><?php echo e($travel->assistant_or_laborers_allowed); ?></div>
        <div class="personal-info appropriation-to-which-travel">
          <?php echo e($travel->appropriation_to_which_travel); ?>

        </div>
        <div class="personal-info should-be-charged"><?php echo e($travel->should_be_charged); ?></div>
        <div class="personal-info remarks-or-special-instructions">
          <?php echo e($travel->remarks_or_special_instructions); ?>

        </div>
        <div class="personal-info recommending-approval"><?php echo e($travel->recommending_approval); ?></div>
        <div class="personal-info approved-by"><?php echo e($travel->approved_by); ?></div>
        <div class="personal-info certifying-officers"><?php echo e($travel->certifying_officers); ?></div>
        <div class="personal-info immediate-supervisor"><?php echo e($travel->immediate_supervisor); ?></div>
        <div class="personal-info supervisor-designation"><?php echo e($travel->supervisor_designation); ?></div>
        <div class="personal-info document-number"><?php echo e($travel->document_number); ?></div>
        <div class="personal-info revision-number"><?php echo e($travel->revision_number); ?></div>
        <div class="personal-info issued-date"><?php echo e($travel->issued_date); ?></div>
        

    </div>
   
</body>
</html>
    
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/travelPDF.blade.php ENDPATH**/ ?>