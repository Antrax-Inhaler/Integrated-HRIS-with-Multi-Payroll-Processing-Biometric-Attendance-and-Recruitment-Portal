<?php echo $__env->make('applicant.psdtopbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <h1 class="page-title">Learning & Development Programs</h1>

    <!-- Form to Add or Edit Learning Development Entries -->
    <h3 class="section-title"><?php echo e(isset($editLearningDevelopment) ? 'Edit Learning & Development Program' : 'Add Learning & Development Program'); ?></h3>
    <form action="<?php echo e(isset($editLearningDevelopment) ? route('applicant.learning_development.update', $editLearningDevelopment->id) : route('applicant.learning_development.store')); ?>" method="POST" class="form-container">
        <?php echo csrf_field(); ?>
        <?php if(isset($editLearningDevelopment)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="form-group">
            <label for="title_of_program">Title of Program:</label>
            <input type="text" id="title_of_program" name="title_of_program" value="<?php echo e($editLearningDevelopment->title_of_program ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="type_of_ld">Type of Learning Development:</label>
            <select id="type_of_ld" name="type_of_ld" required>
                <option value="Managerial" <?php echo e(isset($editLearningDevelopment) && $editLearningDevelopment->type_of_ld == 'Managerial' ? 'selected' : ''); ?>>Managerial</option>
                <option value="Supervisory" <?php echo e(isset($editLearningDevelopment) && $editLearningDevelopment->type_of_ld == 'Supervisory' ? 'selected' : ''); ?>>Supervisory</option>
                <option value="Technical" <?php echo e(isset($editLearningDevelopment) && $editLearningDevelopment->type_of_ld == 'Technical' ? 'selected' : ''); ?>>Technical</option>
                <option value="Other" <?php echo e(isset($editLearningDevelopment) && $editLearningDevelopment->type_of_ld == 'Other' ? 'selected' : ''); ?>>Other</option>
            </select>
        </div>

        <div class="form-group">
            <label for="conducted_by">Conducted/Sponsored By:</label>
            <input type="text" id="conducted_by" name="conducted_by" value="<?php echo e($editLearningDevelopment->conducted_by ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="inclusive_dates_from">From Date:</label>
            <input type="date" id="inclusive_dates_from" name="inclusive_dates_from" value="<?php echo e($editLearningDevelopment->inclusive_dates_from ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="inclusive_dates_to">To Date:</label>
            <input type="date" id="inclusive_dates_to" name="inclusive_dates_to" value="<?php echo e($editLearningDevelopment->inclusive_dates_to ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="number_of_hours">Number of Hours:</label>
            <input type="number" id="number_of_hours" name="number_of_hours" value="<?php echo e($editLearningDevelopment->number_of_hours ?? ''); ?>" required>
        </div>

        <button type="submit" class="submit-button"><?php echo e(isset($editLearningDevelopment) ? 'Update' : 'Add'); ?></button>
    </form>
    <br>
    <hr>

    <!-- Table of Existing Learning Development Entries -->
    <h3 class="section-title">Existing Learning & Development Programs</h3>
    <table class="learning-development-table">
        <thead>
            <tr>
                <th>Title of Program</th>
                <th>Type of Learning Development</th>
                <th>Conducted By</th>
                <th>From Date</th>
                <th>To Date</th>
                <th>Number of Hours</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $learningDevelopments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $development): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($development->title_of_program); ?></td>
                    <td><?php echo e($development->type_of_ld); ?></td>
                    <td><?php echo e($development->conducted_by); ?></td>
                    <td><?php echo e($development->inclusive_dates_from); ?></td>
                    <td><?php echo e($development->inclusive_dates_to); ?></td>
                    <td><?php echo e($development->number_of_hours); ?></td>
                    <td>
                        <a href="<?php echo e(route('applicant.learning_development', ['edit' => $development->id])); ?>" class="edit-link">Edit</a>
                        <form action="<?php echo e(route('applicant.learning_development.delete', $development->id)); ?>" method="POST" class="inline-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-button">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Navigation Buttons -->
    <div class="navigation-buttons">
        <button id="back-button" class="nav-button" onclick="goBack()">Back</button>
        <button id="next-button" class="nav-button" onclick="goNext()">Next</button>
    </div>
</div>

<!-- Navigation Scripts -->
<script>
    function goBack() {
        // Navigate to the specified back URL
        window.location.href = '/applicant/voluntary-work'; // Replace with the actual URL
    }
    
    function goNext() {
        // Navigate to the specified next URL
        window.location.href = '/applicant/other-information'; // Replace with the actual URL
    }
</script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/applicant/learning_development.blade.php ENDPATH**/ ?>