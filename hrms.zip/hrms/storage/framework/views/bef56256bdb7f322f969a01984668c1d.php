<?php echo $__env->make('applicant.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content">
    <div class="job-listings">
        <button class="pds-button" onclick="window.location.href='/applicant/'">
            <i class="fas fa-arrow-left"> Job List
        </button>
    <h2>Your Job Applications</h2>

    <style>
        .content {
            padding-top: 50px;
        }
    
        table {
            width: 100%;
            border-collapse: collapse;
            border-radius: 8px;
            overflow: hidden;
            margin-top: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    
        thead tr {
            background-color: #4caf50;
            color: white;
            text-align: left;
        }
    
        th, td {
            padding: 12px 15px;
        }
    
        tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    
        tbody tr:nth-child(odd) {
            background-color: #e9f7ea;
        }
    
        tbody td {
            border-bottom: 1px solid #ddd;
        }
    
        td:last-child {
            text-align: center;
        }
    
        button {
            background-color: #f44336;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 4px;
        }
    
        button:hover {
            background-color: #d32f2f;
        }
    
        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: bold;
            color: white;
        }
    
        .status-pending {
            background-color: #ff9800;
        }
    
        .status-interview {
            background-color: #03a9f4;
        }
    
        .status-offered {
            background-color: #4caf50;
        }
    
        .status-rejected {
            background-color: #f44336;
        }
    
        h2 {
            color: #388e3c;
            margin-bottom: 10px;
        }
    
        /* Responsive design for card view on small screens */
        @media (max-width: 768px) {
            table, thead, tbody, th, td, tr {
                display: block;
                width: 100%;
            }
    
            thead {
                display: none;
            }
    
            tbody tr {
                margin-bottom: 15px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                border-radius: 8px;
                padding: 15px;
                background-color: #fff;
            }
    
            td {
                display: flex;
                justify-content: space-between;
                padding: 10px 0;
                border-bottom: 1px solid #ddd;
            }
    
            td:before {
                content: attr(data-label);
                font-weight: bold;
                color: #333;
                width: 50%;
                text-align: left;
                flex: 1;
            }
    
            td:last-child {
                border-bottom: none;
            }
        }
    </style>


        <table>
            <thead>
                <tr>
                    <th>Job Title</th>
                    <th>Status</th>
                    <th>Date Applied</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($application->jobListing->job_title); ?></td>
                        <td>
                            <span class="status status-<?php echo e(strtolower($application->status)); ?>">
                                <?php echo e($application->status); ?>

                            </span>
                        </td>
                        <td><?php echo e($application->created_at->format('m/d/Y')); ?></td>
                        <td>
                            <?php if($application->status === 'Pending'): ?>
                                <form method="POST" action="<?php echo e(route('job-applications.cancel', $application->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit">Cancel</button>
                                </form>
                            <?php else: ?>
                                <!-- View Button -->
                                <button 
                                    type="button" 
                                    class="btn btn-info" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#applicationModal<?php echo e($application->id); ?>">
                                    View
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                    <!-- Modal for Viewing Application Details -->
                    <div class="modal fade" id="applicationModal<?php echo e($application->id); ?>" tabindex="-1" aria-labelledby="applicationModalLabel<?php echo e($application->id); ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="applicationModalLabel<?php echo e($application->id); ?>">Application Details</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong>Job Title:</strong> <?php echo e($application->jobListing->job_title); ?></p>
                                    <p><strong>Status:</strong> <?php echo e($application->status); ?></p>
                                    <p><strong>Date Applied:</strong> <?php echo e($application->created_at->format('m/d/Y')); ?></p>
                                    <p><strong>Comments:</strong></p>
                                    <p><?php echo e($application->comment ?? 'No comments available.'); ?></p>
                                    
                                    <?php if($application->status === 'Interview'): ?>
                                        <p><strong>Interview Date:</strong> <?php echo e($application->interview_date ? $application->interview_date->format('m/d/Y H:i') : 'To be scheduled'); ?></p>
                                        <p><strong>Interview Location:</strong> <?php echo e($application->interview_location ?? 'Not provided'); ?></p>
                                        <p><strong>Interviewer Name:</strong> <?php echo e($application->interviewer_name ?? 'Not assigned yet'); ?></p>
                                    <?php endif; ?>
                                    
                                    <?php if($application->status === 'Rejected'): ?>
                                        <p><strong>Rejection Reason:</strong> <?php echo e($application->rejection_reason ?? 'No reason provided.'); ?></p>
                                    <?php endif; ?>
                                    
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No job applications found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>


<!-- Include Bootstrap CSS and JS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <br>
    <br>
    <hr>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <h2>Jobs You Might Be Interested In</h2>

    <?php $__currentLoopData = $jobListings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="job-card">
        <div class="job-card-header">
            <div class="title-container">
                <div class="job-title">
                    <i class="bx bxs-briefcase"></i> <?php echo e($job->job_title); ?>

                </div>
            </div>
            <div class="job-type">
                <span class="job-badge"><?php echo e($job->job_type); ?></span>
            </div>
        </div>

        <div class="job-details">
            <div class="detail-item">
                <i class="bx bxs-building-house"></i>
                <span>Department: </span><?php echo e($job->department); ?>

            </div>
            <div class="detail-item">
                <i class="bx bxs-dollar-circle"></i>
                <span>Salary Range: </span><?php echo e($job->salary_range); ?>

            </div>
            <div class="detail-item">
                <i class="bx bxs-graduation"></i>
                <span>Education Requirement: </span><?php echo e($job->education_requirement); ?>

            </div>
            <div class="detail-item">
                <i class="bx bx-calendar-event"></i>
                <span>Deadline: </span><?php echo e($job->application_deadline->format('jS F Y')); ?>

            </div>
            <div class="detail-item">
                <i class="bx bx-calendar-check"></i>
                <span>Posted: </span><?php echo e($job->posted_date->format('jS F Y')); ?>

            </div>
        </div>

        <div class="description-container">
            <p><?php echo e(\Illuminate\Support\Str::limit($job->job_description, 150)); ?></p>
        </div>

        <div class="apply-section">
            <button class="apply-button" data-job-id="<?php echo e($job->id); ?>">
                <i class="bx bxs-paper-plane"></i> Apply Now
            </button>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var isAuthenticated = <?php echo json_encode(auth()->check(), 15, 512) ?>;

        document.querySelectorAll('.apply-button').forEach(function (button) {
            button.addEventListener('click', function () {
                if (!isAuthenticated) {
                    window.location.href = '/applicant/login';
                } else {
                    var jobId = button.getAttribute('data-job-id');
                    window.location.href = '/apply/' + jobId;
                }
            });
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/applicant/application_list.blade.php ENDPATH**/ ?>