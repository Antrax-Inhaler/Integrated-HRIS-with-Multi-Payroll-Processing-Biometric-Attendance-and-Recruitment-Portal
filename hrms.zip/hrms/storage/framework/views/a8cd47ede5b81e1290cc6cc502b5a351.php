<div>
    <h5>Member: <?php echo e($payrollItem->member->given_name); ?> <?php echo e($payrollItem->member->middle_name); ?> <?php echo e($payrollItem->member->surname); ?></h5>
    <p>Basic Salary: <?php echo e($payrollItem->basic_salary); ?></p>
    <p>Gross Salary: <?php echo e($payrollItem->gross_salary); ?></p>
    <p>Deductions: <?php echo e($totalDeductions); ?></p>
    <p>Bonuses: <?php echo e($totalBonuses); ?></p>
    <p>Net Salary: <?php echo e($payrollItem->net_salary); ?></p>
    
    <hr>
    
    <h6>Attendance Details</h6>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Date</th>
                <th>AM IN</th>
                <th>AM OUT</th>
                <th>PM IN</th>
                <th>PM OUT</th>
                <th>Total Hours</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $payroll->payrollItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $item->groupedAttendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($attendance['date']); ?></td>
                        <td><?php echo e($attendance['am_in'] ?? 'N/A'); ?></td>
                        <td><?php echo e($attendance['am_out'] ?? 'N/A'); ?></td>
                        <td><?php echo e($attendance['pm_in'] ?? 'N/A'); ?></td>
                        <td><?php echo e($attendance['pm_out'] ?? 'N/A'); ?></td>
                        <td><?php echo e($attendance['total_hours']); ?> hours</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>Total Hours: <p><?php echo e($payrollItem->total_hours); ?></p></td>
            </tr>
        </tbody>
    </table>
    
    
    
    
    <hr>
    
    <h6>Deductions</h6>
    <table>
        <thead>
            <tr>
                <th>Description</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $deductions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deduction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($deduction->description); ?></td>
                    <td><?php echo e($deduction->amount); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
    <h6>Total Deductions: <?php echo e($totalDeductions); ?></h6>
    
    <hr>
    
    <h6>Bonuses</h6>
    <table>
        <thead>
            <tr>
                <th>Description</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bonuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bonus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($bonus->description); ?></td>
                    <td><?php echo e($bonus->amount); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
    <h6>Total Bonuses: <?php echo e($totalBonuses); ?></h6>
</div>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/payslip_detail_modal.blade.php ENDPATH**/ ?>