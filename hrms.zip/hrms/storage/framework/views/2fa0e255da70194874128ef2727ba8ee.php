

<section class="home-section" style="width: calc(100% - 58px); overflow:scroll">

<style>
    h2 {
        color: #2F4F4F; /* Dark greenish color */
        margin-bottom: 20px;
    }

    .form-group label {
        font-weight: bold;
        color: #2F4F4F; /* Dark greenish color */
    }

    .form-control {
        border-radius: 4px;
        border: 1px solid #ccc;
        padding: 10px;
    }

    .btn-primary {
        background-color: #007BFF;
        border-color: #007BFF;
        color: white;
        margin-top: 20px;
    }
</style>

<div class="container mt-5">
    <h2>Issue Bonus</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('bonus.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- Employee -->
        <div class="form-group">
            <label for="member_id">Employee</label>
            <select class="form-control" id="member_id" name="member_id" required>
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($member->id); ?>"><?php echo e($member->surname); ?>, <?php echo e($member->given_name); ?> <?php echo e($member->middle_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Bonus Name -->
        <div class="form-group">
            <label for="bonus_name">Bonus Name</label>
            <input type="text" class="form-control" id="bonus_name" name="bonus_name" required>
        </div>

        <!-- Description -->
        <div class="form-group">
            <label for="description">Description</label>
            <textarea class="form-control" id="description" name="description"></textarea>
        </div>

        <!-- Amount -->
        <div class="form-group">
            <label for="amount">Amount</label>
            <input type="number" class="form-control" id="amount" name="amount" required>
        </div>

        <!-- Effective Date -->
        <div class="form-group">
            <label for="effective_date">Effective Date</label>
            <input type="date" class="form-control" id="effective_date" name="effective_date" required>
        </div>

        <button type="submit" class="btn btn-primary">Issue Bonus</button>
    </form>
</div>

</section>

<?php echo $__env->make('admin.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/issue-bonus.blade.php ENDPATH**/ ?>