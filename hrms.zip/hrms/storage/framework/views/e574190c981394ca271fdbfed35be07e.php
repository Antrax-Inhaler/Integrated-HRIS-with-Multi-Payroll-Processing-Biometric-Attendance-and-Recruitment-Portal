<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payroll Slip</title>
    <style>
        body {
            font-family: "Times New Roman", sans-serif;
            font-size: 14px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            max-height: 900px;
        }
        td, th {
            padding: 5px;
            border: 1px solid black;
            text-align: right;
            vertical-align: top;
        }
        .header {
            text-align: left;
            font-weight: bold;
        }
        .title {
            font-weight: bold;
            text-align: left !important;
        }
        .green {
            color: green;
        }
        .red {
            color: red;
        }
        .underline {
        }
    </style>
</head>
<body>

    <?php $__currentLoopData = $payrollData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <table>

        <?php
            $item = $data['item']; // Payroll item details
            $bonuses = $data['bonuses'];
            $deductions = $data['deductions'];

            // Determine how many rows to display (minimum 10 rows)
            $maxRows = max(8, max(count($bonuses), count($deductions)));
        ?>

        <tr>
            <td colspan="6" class="header">DEPARTMENT OF AGRICULTURE(REGION IV-B MIMAROPA)</td>
        </tr>
        <tr>
            <td colspan="3" class="header">REGIONAL OFFICE</td>
            <td colspan="3" class="header" style="text-align: right;">Pay Slip</td>

        </tr>
        <tr>
            <?php
    $surname = strtoupper($item->member->surname);
    $firstName = strtoupper($item->member->given_name);
    $middleInitial = $item->member->middle_name ? strtoupper(substr($item->member->middle_name, 0, 1)) . '.' : '';
?>

<td class="member-name title" colspan="3">
    <?php echo e($firstName); ?>, <?php echo e($surname); ?> <?php echo e($middleInitial); ?>

</td>
            <td colspan="3" class="month-year"><b><?php echo e(now()->format('F Y')); ?></b></td>

        </tr>
        <tr>
            <td>Monthly Rate</td>
            <td><?php echo e(number_format($item->basic_salary, 2)); ?></td>
            <td>Lates</td>
            <td><?php echo e($item->late_count); ?></td>
            <td class="green" >Gross</td>
            <td><?php echo e(number_format($item->gross_salary, 2)); ?></td>
        </tr>
        <tr>
            <td>Pera/Aca</td>
            <td><?php echo e(number_format($item->pera_aca_total, 2)); ?></td>
            <td>Amount</td>
            <td><?php echo e(number_format($item->late_deduction, 2)); ?></td>
            <td>Adjustment</td>
            <td><?php echo e(number_format($item->adjustment_amount, 2)); ?></td>
        </tr>
        <tr>
            <td>Add/Com</td>
            <td><?php echo e(number_format($item->add_com_total, 2)); ?></td>
            <td>Undertime</td>
            <td><?php echo e($item->undertime_hours); ?></td>
            <td>Deductions</td>
            <td><?php echo e(number_format($item->total_deductions, 2)); ?></td>
        </tr>
        <tr>
            <td>Days</td>
            <td>-</td>
            <td>Amount</td>
            <td><?php echo e(number_format($item->undertime_deduction, 2)); ?></td>
            <td>Net Pay</td>
            <td><?php echo e(number_format($item->net_salary, 2)); ?></td>
        </tr>
        <tr>
            <td colspan="3" class="green underline" style="text-align: center;">Adjustments</td>
            <td colspan="3" class="red underline" style="text-align: center;">Deductions</td>
        </tr>

        <?php for($i = 0; $i < $maxRows; $i++): ?>
            <tr>
                <td class="bonus-name" colspan="2">
                    <?php echo e($bonuses[$i]->bonus_name ?? ''); ?>

                </td>
                <td class="bonus-amount">
                    <?php echo e(isset($bonuses[$i]) ? number_format($bonuses[$i]->amount, 2) : '0.00'); ?>

                </td>
                <td class="deduction-name" colspan="2">
                    <?php echo e($deductions[$i]->deduction_name ?? ''); ?>

                </td>
                <td class="deduction-amount">
                    <?php echo e(isset($deductions[$i]) ? number_format($deductions[$i]->amount, 2) : '0.00'); ?>

                </td>
            </tr>
        <?php endfor; ?>
    </table>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/payslip.blade.php ENDPATH**/ ?>