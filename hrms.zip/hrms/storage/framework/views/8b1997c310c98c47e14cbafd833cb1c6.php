<?php echo $__env->make('admin.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="home-section" style="width: calc(100% - 58px); overflow:scroll">

<div class="container mt-5">
    <h2>Member Verification</h2>

    <!-- Members Pending Verification Table -->
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>ID</th>
            <th>Surname</th>
            <th>Given Name</th>
            <th>Email</th>
            <th>Contact Number</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $pendingMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($member->id); ?></td>
                <td><?php echo e($member->surname); ?></td>
                <td><?php echo e($member->given_name); ?></td>
                <td><?php echo e($member->email); ?></td>
                <td><?php echo e($member->contact_number); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.verify-member.view', $member->id)); ?>" class="btn btn-info btn-sm">View</a>
                    <form action="<?php echo e(route('admin.verify-member.verify', $member->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <button type="submit" class="btn btn-success btn-sm">Verify</button>
                    </form>
                    <form action="<?php echo e(route('admin.verify-member.reject', $member->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

</section>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/verify-member.blade.php ENDPATH**/ ?>