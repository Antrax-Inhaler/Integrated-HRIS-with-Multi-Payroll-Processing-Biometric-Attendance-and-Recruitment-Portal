<?php echo $__env->make('applicant.psdtopbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<h1 class="page-title">References</h1>
<!-- Family Background Form -->
<h3 class="section-title">Family Background</h3>
<form method="POST" action="<?php echo e(url('applicant/referencespds/family-background')); ?>" class="">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label>Spouse Surname:</label>
        <input type="text" name="spouse_surname" value="<?php echo e($familyBackground->spouse_surname ?? ''); ?>" required>
    </div>

    <div class="form-group">
        <label>Spouse First Name:</label>
        <input type="text" name="spouse_first_name" value="<?php echo e($familyBackground->spouse_first_name ?? ''); ?>" required>
    </div>

    <div class="form-group">
        <label>Spouse Middle Name:</label>
        <input type="text" name="spouse_middle_name" value="<?php echo e($familyBackground->spouse_middle_name ?? ''); ?>" required>
    </div>

    <div class="form-group">
        <label>Spouse Occupation:</label>
        <input type="text" name="spouse_occupation" value="<?php echo e($familyBackground->spouse_occupation ?? ''); ?>">
    </div>

    <div class="form-group">
        <label>Spouse Employer Name:</label>
        <input type="text" name="spouse_employer_name" value="<?php echo e($familyBackground->spouse_employer_name ?? ''); ?>">
    </div>

    <div class="form-group">
        <label>Spouse Business Address:</label>
        <input type="text" name="spouse_business_address" value="<?php echo e($familyBackground->spouse_business_address ?? ''); ?>">
    </div>

    <div class="form-group">
        <label>Spouse Telephone No:</label>
        <input type="text" name="spouse_telephone_no" value="<?php echo e($familyBackground->spouse_telephone_no ?? ''); ?>">
    </div>

    <div class="form-group">
        <label>Father Surname:</label>
        <input type="text" name="father_surname" value="<?php echo e($familyBackground->father_surname ?? ''); ?>" required>
    </div>

    <div class="form-group">
        <label>Father First Name:</label>
        <input type="text" name="father_first_name" value="<?php echo e($familyBackground->father_first_name ?? ''); ?>" required>
    </div>

    <div class="form-group">
        <label>Father Middle Name:</label>
        <input type="text" name="father_middle_name" value="<?php echo e($familyBackground->father_middle_name ?? ''); ?>">
    </div>

    <div class="form-group">
        <label>Mother Maiden Name:</label>
        <input type="text" name="mother_maiden_name" value="<?php echo e($familyBackground->mother_maiden_name ?? ''); ?>">
    </div>

    <button type="submit" class="submit-button">Save Family Background</button>
</form>
<hr>

<!-- Children Section -->
<h3 class="section-title">Children</h3>

<!-- List of Children -->
<?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form method="POST" action="<?php echo e(url('applicant/referencespds/child/' . $child->id)); ?>" class="form-container">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label>Child Name:</label>
            <input type="text" name="child_name" value="<?php echo e($child->child_name); ?>" required>
        </div>

        <div class="form-group">
            <label>Date of Birth:</label>
            <input type="date" name="date_of_birth" value="<?php echo e($child->date_of_birth); ?>" required>
        </div>

        <div class="button-group">
            <button type="submit" class="update-button" title="Update Child">
                <i class="fas fa-edit"></i> <!-- Font Awesome edit icon -->
            </button>
            <form method="POST" action="<?php echo e(url('applicant/referencespds/child/' . $child->id)); ?>" class="delete-form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="delete-button" title="Delete Child">
                    <i class="fas fa-trash"></i> <!-- Font Awesome trash icon -->
                </button>
            </form>
        </div>
    </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(url('applicant/referencespds/child')); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label>Add Child Name:</label>
        <input type="text" name="child_name" required>
    </div>

    <div class="form-group">
        <label>Date of Birth:</label>
        <input type="date" name="date_of_birth" required>
    </div>

    <button type="submit" class="submit-button">Add Child</button>
</form>
<br>
<hr>
<div class="navigation-buttons">
    <button id="back-button" class="nav-button" onclick="goBack()">Back</button>
    <button id="next-button" class="nav-button" onclick="goNext()">Next</button>
</div>

</div>
</body>
<script>
    function goBack() {
        // Navigate to the specified back URL
        window.location.href = '/applicant/personal-information'; // Replace with the actual URL
    }
    
    function goNext() {
        // Navigate to the specified next URL
        window.location.href = '/applicant/educational-background'; // Replace with the actual URL
    }
    </script>
    
</html><?php /**PATH C:\xampp\htdocs\hrms\resources\views/applicant/references2.blade.php ENDPATH**/ ?>