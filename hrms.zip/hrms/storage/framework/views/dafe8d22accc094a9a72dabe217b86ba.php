<?php echo $__env->make('member.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<section class="home-section" style="width: calc(100% - 58px); overflow: scroll">

<h1>Log Notifications</h1>
    <div class="table table-bordered">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Message</th>
                    <th>Date and Time</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($notification->message); ?></td>
                        <td><?php echo e($notification->created_at->format('M d, Y h:i A')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3" class="text-center">No log notifications found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div><?php /**PATH C:\xampp\htdocs\hrms\resources\views/member/logs.blade.php ENDPATH**/ ?>