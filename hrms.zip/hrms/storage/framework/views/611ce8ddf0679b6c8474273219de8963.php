<?php echo $__env->make('admin.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Payroll Detail Page -->
<section class="home-section" style="width: calc(100% - 58px); overflow-x:scroll">
<h1>Payroll Details for <?php echo e(\Carbon\Carbon::parse($payroll->date_from)->format('F Y')); ?></h1>
<br>
<style>
    .button-navigations{
        display: flex;
        justify-content: space-between;
    }
    .btn-warning{
        background-color: #FFC107;
    }
</style>
<!-- Payroll Table -->
<div class="button-navigations">
    <form action="<?php echo e(route('admin.payrollCS.recalculate', $payroll->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-warning">Recalculate Payroll</button>
    </form>
    <div class="left-buttons">
    <a href="<?php echo e(route('admin.payrollCS.print', $payroll->id)); ?>" target="_blank" class="btn btn-success">
        Print Payroll
    </a>
    <a href="<?php echo e(route('admin.payslipCS.printAll', $payroll->id)); ?>" target="_blank" class="btn btn-primary mb-3">
        Print All Payslips
    </a>
</div>
</div>
<br>
<!-- Payroll Table -->
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Member Name</th>
            <th>Basic Salary</th>
            <th>Total Hours</th>
            <th>Hourly Rate</th>
            <th>Gross Salary</th>
            <th>Add Com</th> <!-- New Column -->
            <th>Pera Aca</th>
            <th>Late Deduction</th> <!-- New Column -->
            <th>Late Count</th>  
            <th>Undertime Hours</th> <!-- New Column -->
            <th>Undertime Deduction</th> <!-- New Column -->
            <th>Deductions</th>
            <th>Net Salary</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $payroll->payrollItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->member->surname); ?></td>
                <td><?php echo e($item->basic_salary); ?></td>
                <td><?php echo e($item->total_hours); ?></td>
                <td><?php echo e($item->hourly_rate); ?></td>
                <td><?php echo e($item->gross_salary); ?></td>
                <td><?php echo e($item->add_com_total ?? '0.00'); ?></td> <!-- Display Add Com -->
                <td><?php echo e($item->pera_aca_total ?? '0.00'); ?></td> <!-- Display Pera Aca -->
                <td><?php echo e($item->late_deduction); ?></td> <!-- Late Deduction Data -->
                <td><?php echo e($item->late_count); ?></td>     <!-- Late Count Data -->
                <td><?php echo e($item->undertime_hours ?? '0.00'); ?></td> <!-- Undertime Hours Data -->
                <td><?php echo e($item->undertime_deduction ?? '0.00'); ?></td> <!-- Undertime Deduction Data -->
                <td><?php echo e($item->totalDeductions); ?></td>
                <td><?php echo e($item->net_salary); ?></td>
                <td>
                    <!-- Button to Trigger Modal -->
                    <button class="btn btn-primary" data-toggle="modal" data-target="#payslipModal<?php echo e($item->id); ?>">
                        View Payslip
                    </button>

                    <!-- Payslip Modal -->
                    <div class="modal fade" id="payslipModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="payslipModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="payslipModalLabel<?php echo e($item->id); ?>">Payslip for <?php echo e($item->member->full_name); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <?php echo $__env->make('admin.payslip_detail_modal', ['payrollItem' => $item, 'attendances' => $item->attendances, 'deductions' => $item->deductions, 'bonuses' => $item->bonuses, 'totalHoursWorked' => $item->totalHoursWorked, 'totalDeductions' => $item->totalDeductions, 'totalBonuses' => $item->totalBonuses], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>

</section>


</script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/payroll_semi_contractual_monthly_detail.blade.php ENDPATH**/ ?>