<?php echo $__env->make('admin.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="home-section" style="width: calc(100% - 58px); overflow:scroll">
    <div class="container mt-5">
        <h2>Adjustments Management</h2>

        <!-- Button to trigger add adjustment modal -->
        <button class="btn btn-success mb-3" data-toggle="modal" data-target="#addAdjustmentModal">Add Adjustment</button>

        <!-- Adjustments Table -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Member Name</th>
                    <th>Adjustment Name</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Effective Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $adjustments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adjustment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($adjustment->id); ?></td>
                    <td><?php echo e($adjustment->member->given_name); ?> <?php echo e($adjustment->member->surname); ?></td>
                    <td><?php echo e($adjustment->bonus_name); ?></td>
                    <td><?php echo e($adjustment->description); ?></td>
                    <td><?php echo e($adjustment->amount); ?></td>
                    <td><?php echo e($adjustment->effective_date); ?></td>
                    <td>
                        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editAdjustmentModal<?php echo e($adjustment->id); ?>">Edit</button>
                        <form action="<?php echo e(route('adjustment.destroy', $adjustment->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>

                <!-- Edit Adjustment Modal -->
                <div class="modal fade" id="editAdjustmentModal<?php echo e($adjustment->id); ?>" tabindex="-1" role="dialog">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Adjustment</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('adjustment.update', $adjustment->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="form-group">
                                        <label for="member_id">Member</label>
                                        <select name="member_id" class="form-control" required>
                                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($member->id); ?>" <?php echo e($member->id == $adjustment->member_id ? 'selected' : ''); ?>>
                                                    <?php echo e($member->given_name); ?> <?php echo e($member->surname); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="bonus_name">Adjustment Name</label>
                                        <input type="text" class="form-control" name="bonus_name" value="<?php echo e($adjustment->bonus_name); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea name="description" class="form-control"><?php echo e($adjustment->description); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="amount">Amount</label>
                                        <input type="number" class="form-control" name="amount" value="<?php echo e($adjustment->amount); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="effective_date">Effective Date</label>
                                        <input type="date" class="form-control" name="effective_date" value="<?php echo e($adjustment->effective_date); ?>" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Add Adjustment Modal -->
    <div class="modal fade" id="addAdjustmentModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Adjustment</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('adjustment.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="member_id">Member</label>
                            <select name="member_id" class="form-control" required>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($member->id); ?>"><?php echo e($member->given_name); ?> <?php echo e($member->surname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="bonus_name">Adjustment Name</label>
                            <input type="text" class="form-control" name="bonus_name" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input type="number" class="form-control" name="amount" required>
                        </div>
                        <div class="form-group">
                            <label for="effective_date">Effective Date</label>
                            <input type="date" class="form-control" name="effective_date" required>
                        </div>
                        <button type="submit" class="btn btn-success">Add Adjustment</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Include necessary scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/adjustment.blade.php ENDPATH**/ ?>