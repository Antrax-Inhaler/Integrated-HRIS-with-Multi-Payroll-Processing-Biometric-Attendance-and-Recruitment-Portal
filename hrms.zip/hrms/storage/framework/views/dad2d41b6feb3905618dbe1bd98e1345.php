
<?php echo $__env->make('admin.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<section class="home-section" style="width: calc(100% - 58px);overflow:scroll">

<style>

#loading_spinner {
    text-align: center;
    margin-top: 10px;
}

#image_preview {
    border-radius: 50%;
    margin-top: 10px;
    width: 100px;
    height: 100px;
}

</style>
<div class="container mt-5">


    <h2>Employee Management</h2>
    <form action="<?php echo e(route('admin.index')); ?>" method="GET">
        <div class="row mb-3">
            <!-- Search Field -->
            <div class="col-md-3">
                <input type="text" name="search" class="form-control" placeholder="Search by name" value="<?php echo e(request('search')); ?>">
            </div>
    
            <!-- Position Filter Dropdown -->
            <div class="col-md-3">
                <select name="position" class="form-control">
                    <option value="">All Positions</option>
                    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($position); ?>" <?php echo e(request('position') == $position ? 'selected' : ''); ?>><?php echo e($position); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
    
            <!-- Department Filter Dropdown -->
            <div class="col-md-3">
                <select name="department" class="form-control">
                    <option value="">All Departments</option>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department); ?>" <?php echo e(request('department') == $department ? 'selected' : ''); ?>><?php echo e($department); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
    
            <!-- Filter Button -->
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary">Filter</button>
            </div>
        </div>
    </form>
    
    
    <!-- Button to trigger add member modal -->
    <button class="btn btn-success mb-3" data-toggle="modal" data-target="#addMemberModal">Add Employee</button>
    <br>
    <br>
    
    <!-- Members Table -->
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>ID</th>
            <th>Profile Picture</th>
            <th>Surname</th>
            <th>Given Name</th>
            <th>Middle Name</th>
            <th>Email</th>
            <th>Contact Number</th>
            <th>Position</th>
            <th>Department</th>
            <th>Is Verified</th>
            <th>Valid ID</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th>Fingerprint ID</th>
            <th>Employment Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($member->id); ?></td>
                <td>
                    <img src="<?php echo e($member->profile_picture ? asset('storage/' . $member->profile_picture) : asset('storage/profile_pictures/3135715.png')); ?>" 
                         alt="Profile Picture" 
                         style="width: 50px; height: 50px; border-radius: 50%;" />
                </td>
                <td><?php echo e($member->surname); ?></td>
                <td><?php echo e($member->given_name); ?></td>
                <td><?php echo e($member->middle_name); ?></td>
                <td><?php echo e($member->email); ?></td>
                <td><?php echo e($member->contact_number); ?></td>
                <td><?php echo e($member->position ? $member->position->position_name : 'N/A'); ?></td>
                <td><?php echo e($member->department ? $member->department->department_name : 'N/A'); ?></td>
                
                
                
                <td><?php echo e($member->is_verified ? 'Yes' : 'No'); ?></td>
                <td>
                    <?php if($member->valid_id): ?>
                        <a href="<?php echo e(asset('storage/' . $member->valid_id)); ?>" target="_blank">View ID</a>
                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </td>
                <td><?php echo e($member->created_at ? $member->created_at->format('Y-m-d H:i:s') : 'N/A'); ?></td>
                <td><?php echo e($member->updated_at ? $member->updated_at->format('Y-m-d H:i:s') : 'N/A'); ?></td>
                <td><?php echo e($member->fingerprint_id ?? 'N/A'); ?></td>
                <td><?php echo e(ucfirst($member->employment_status)); ?></td>
                <td>
                    <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editMemberModal<?php echo e($member->id); ?>">Edit</button>
                    <form action="<?php echo e(url('/admin/members/delete', $member->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>

            <!-- Edit Member Modal -->
            <div class="modal fade" id="editMemberModal<?php echo e($member->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editMemberModalLabel<?php echo e($member->id); ?>" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editMemberModalLabel<?php echo e($member->id); ?>">Edit Member</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(url('/admin/members/update', $member->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                
                                <div class="form-group">
                                    <label for="editProfilePicture<?php echo e($member->id); ?>">Profile Picture</label>
                                    <input type="file" class="form-control-file" id="editProfilePicture<?php echo e($member->id); ?>" name="profile_picture" accept="image/*">
                                    <img id="editPreviewImage<?php echo e($member->id); ?>" src="#" alt="Profile Picture Preview" class="img-thumbnail mt-2" style="display:none; width: 100px; height: 100px; border-radius: 50%;">
                                    <div id="editLoadingSpinner<?php echo e($member->id); ?>" style="display:none; text-align: center;">
                                        <img src="/img/loading.gif" alt="Loading" style="width: 50px; height: 50px;">
                                    </div>
                                </div>                                
                                <!-- Surname -->
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bx bx-user"></i> <!-- Changed icon class -->
                                        </span>
                                        <input type="text" class="form-control" name="surname" placeholder="Surname" value="<?php echo e($member->surname); ?>" required>
                                    </div>
                                </div>
                                <!-- Given Name -->
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bx bx-user"></i> <!-- Changed icon class -->
                                        </span>
                                        <input type="text" class="form-control" name="given_name" placeholder="Given Name" value="<?php echo e($member->given_name); ?>" required>
                                    </div>
                                </div>
                                <!-- Middle Name -->
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bx bx-user"></i> <!-- Changed icon class -->
                                        </span>
                                        <input type="text" class="form-control" name="middle_name" placeholder="Middle Name" value="<?php echo e($member->middle_name); ?>">
                                    </div>
                                </div>
                                <!-- Email -->
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bx bx-envelope"></i> <!-- Changed icon class -->
                                        </span>
                                        <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e($member->email); ?>" required>
                                    </div>
                                </div>
                                <!-- Contact Number -->
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bx bx-phone"></i> <!-- Changed icon class -->
                                        </span>
                                        <input type="text" class="form-control" name="contact_number" placeholder="Contact Number" value="<?php echo e($member->contact_number); ?>" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bx bx-phone"></i> <!-- Changed icon class -->
                                        </span>
                                        <input type="number" class="form-control" name="fingerprint_id" placeholder="Fingerprint ID" value="<?php echo e($member->fingerprint_id); ?>" required>
                                    </div>
                                </div>
                              <!-- Position -->
<div class="form-group">
    <label for="position">Position</label>
    <div class="input-group">
        <span class="input-group-text"></span>
        <select name="position" id="position" class="form-control">
            <option value="" disabled selected>Select Position</option>
            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($position->id); ?>" 
                    <?php echo e($member->position == $position->id ? 'selected' : ''); ?>>
                    <?php echo e($position->position_name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<!-- Department -->
<div class="form-group">
    <label for="department">Department</label>
    <div class="input-group">
        <span class="input-group-text"></span>
        <select name="department" id="department" class="form-control">
            <option value="" disabled selected>Select Department</option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($department->id); ?>" 
                    <?php echo e($member->department == $department->id ? 'selected' : ''); ?>>
                    <?php echo e($department->department_name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </form>                                                
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- Add Member Modal -->
<div class="modal fade" id="addMemberModal" tabindex="-1" role="dialog" aria-labelledby="addMemberModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addMemberModalLabel">Add Member</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(url('/admin/members/store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="profilePicture">Profile Picture</label>
                        <input type="file" class="form-control-file" id="profilePicture" name="profile_picture" accept="image/*">
                        <img id="previewImage" src="#" alt="Profile Picture Preview" class="img-thumbnail mt-2" style="display:none; width: 100px; height: 100px; border-radius: 50%;">
                        <div id="loadingSpinner" style="display:none; text-align: center;">
                            <img src="/img/loading.gif" alt="Loading" style="width: 50px; height: 50px;">
                        </div>
                    </div>                    
                    <div class="form-group">
                        <label for="surname">Surname</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bx bx-user"></i> <!-- User icon -->
                            </span>
                            <input type="text" class="form-control" name="surname" placeholder="Surname" required>
                        </div>
                    </div>
                
                    <!-- Given Name -->
                    <div class="form-group">
                        <label for="given_name">Given Name</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bx bx-user"></i> <!-- User icon -->
                            </span>
                            <input type="text" class="form-control" name="given_name" placeholder="Given Name" required>
                        </div>
                    </div>
                
                    <!-- Middle Name -->
                    <div class="form-group">
                        <label for="middle_name">Middle Name</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bx bx-user"></i> <!-- User icon -->
                            </span>
                            <input type="text" class="form-control" name="middle_name" placeholder="Middle Name">
                        </div>
                    </div>
                
                    <!-- Email -->
                    <div class="form-group">
                        <label for="email">Email</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bx bx-envelope"></i> <!-- Envelope icon -->
                            </span>
                            <input type="email" class="form-control" name="email" placeholder="Email" required>
                        </div>
                    </div>
                
                    <!-- Password -->
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bx bx-lock"></i> <!-- Lock icon -->
                            </span>
                            <input type="password" class="form-control" name="password" placeholder="Password" required>
                        </div>
                    </div>
                
                    <!-- Contact Number -->
                    <div class="form-group">
                        <label for="contact_number">Contact Number</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bx bx-phone"></i> <!-- Phone icon -->
                            </span>
                            <input type="text" class="form-control" name="contact_number" placeholder="Contact Number" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bx bx-phone"></i> <!-- Changed icon class -->
                            </span>
                            <input type="number" class="form-control" name="fingerprint_id" placeholder="Fingerprint ID" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="position">Position</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bx bx-briefcase"></i> <!-- Icon for position -->
                            </span>
                            <select id="position" class="form-control" name="position">
                                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($position->name); ?>" <?php echo e($position->id == $member->position ? 'selected' : ''); ?>>
                                        <?php echo e($position->position_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Department -->
                    <div class="form-group">
                        <label for="department">Department</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bx bx-building-house"></i> <!-- Icon for department -->
                            </span>
                            <select id="department" class="form-control" name="department">
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->name); ?>" <?php echo e($department->id == $member->department ? 'selected' : ''); ?>>
                                        <?php echo e($department->department_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-success">Add Employee</button>
                </form>                
            </div>
        </div>
    </div>
</div>
</section>
<script>
    document.getElementById('profilePicture').addEventListener('change', function (e) {
        let reader = new FileReader();
        let loadingSpinner = document.getElementById('loadingSpinner');
        let previewImage = document.getElementById('previewImage');

        // Show the loading spinner
        loadingSpinner.style.display = 'block';
        previewImage.style.display = 'none';

        reader.onload = function (e) {
            previewImage.src = e.target.result;
            previewImage.style.display = 'block';
            loadingSpinner.style.display = 'none'; // Hide the loading spinner
        }
        reader.readAsDataURL(e.target.files[0]);
    });

    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    document.getElementById('editProfilePicture<?php echo e($member->id); ?>').addEventListener('change', function (e) {
        let reader = new FileReader();
        let loadingSpinner = document.getElementById('editLoadingSpinner<?php echo e($member->id); ?>');
        let previewImage = document.getElementById('editPreviewImage<?php echo e($member->id); ?>');

        // Show the loading spinner
        loadingSpinner.style.display = 'block';
        previewImage.style.display = 'none';

        reader.onload = function (e) {
            previewImage.src = e.target.result;
            previewImage.style.display = 'block';
            loadingSpinner.style.display = 'none'; // Hide the loading spinner
        }
        reader.readAsDataURL(e.target.files[0]);
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</script>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/members.blade.php ENDPATH**/ ?>