<!-- resources/views/applicant/educational_background.blade.php -->

<h1>Educational Background</h1>

<!-- Show success or error messages -->
<?php if(session('success')): ?>
    <div><?php echo e(session('success')); ?></div>
<?php endif; ?>

<!-- Form to add a new educational background entry -->
<h2>Add New Educational Background</h2>
<form method="POST" action="<?php echo e(url('applicant/educational-background')); ?>">
    <?php echo csrf_field(); ?>
    <label>Level:</label>
    <select name="level">
        <option value="Elementary">Elementary</option>
        <option value="Secondary">Secondary</option>
        <option value="Vocational">Vocational</option>
        <option value="College">College</option>
        <option value="Graduate Studies">Graduate Studies</option>
    </select><br>

    <label>School Name:</label>
    <input type="text" name="school_name" required><br>

    <label>Period of Attendance From:</label>
    <input type="number" name="period_of_attendance_from" required><br>

    <label>Period of Attendance To:</label>
    <input type="number" name="period_of_attendance_to"><br>

    <label>Course Name:</label>
    <input type="text" name="course_name"><br>

    <label>Year Graduated:</label>
    <input type="number" name="year_graduated"><br>

    <label>Highest Level/Units Earned:</label>
    <input type="text" name="highest_level_units_earned"><br>

    <label>Honors Received:</label>
    <input type="text" name="honors_received"><br>

    <button type="submit">Add</button>
</form>

<!-- Display each educational background for the current user -->
<?php $__currentLoopData = $educationalBackgrounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $background): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3><?php echo e($background->level); ?> - <?php echo e($background->school_name); ?></h3>

    <!-- Form to update existing educational background entry -->
    <form method="POST" action="<?php echo e(url('applicant/educational-background/'.$background->id)); ?>">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <label>School Name:</label>
        <input type="text" name="school_name" value="<?php echo e($background->school_name); ?>" required><br>

        <label>Period of Attendance From:</label>
        <input type="number" name="period_of_attendance_from" value="<?php echo e($background->period_of_attendance_from); ?>" required><br>

        <label>Period of Attendance To:</label>
        <input type="number" name="period_of_attendance_to" value="<?php echo e($background->period_of_attendance_to); ?>"><br>

        <label>Course Name:</label>
        <input type="text" name="course_name" value="<?php echo e($background->course_name); ?>"><br>

        <label>Year Graduated:</label>
        <input type="number" name="year_graduated" value="<?php echo e($background->year_graduated); ?>"><br>

        <label>Highest Level/Units Earned:</label>
        <input type="text" name="highest_level_units_earned" value="<?php echo e($background->highest_level_units_earned); ?>"><br>

        <label>Honors Received:</label>
        <input type="text" name="honors_received" value="<?php echo e($background->honors_received); ?>"><br>

        <button type="submit">Update</button>
    </form>

    <!-- Form to delete existing educational background entry -->
    <form method="POST" action="<?php echo e(url('applicant/educational-background/'.$background->id)); ?>">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <button type="submit">Delete</button>
    </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/applicant/educational_background.blade.php ENDPATH**/ ?>