<?php echo $__env->make('admin.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="home-section" style="width: calc(100% - 58px); overflow:scroll">

    <div class="container mt-5">
        <h2>Travel Applications Management</h2>

        <!-- Button to trigger add travel application modal -->
        

        <!-- Travel Applications Table -->
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Member Name</th>
                <th>Destination</th>
                <th>Departure Date</th>
                <th>Return Date</th>
                <th>Status</th>
                <th>Actions</th>
        
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($travel->id); ?></td>

                    <!-- Check if member relationship exists to avoid errors -->
                    <td>
                        <?php echo e(optional($travel->member)->given_name ?? 'N/A'); ?> 
                        <?php echo e(optional($travel->member)->surname ?? ''); ?>

                    </td>
        
                    <td><?php echo e($travel->destination); ?></td>
        
                    <!-- Format dates for better readability -->
                    <td><?php echo e(\Carbon\Carbon::parse($travel->departure_date)->format('M d, Y')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($travel->return_date)->format('M d, Y')); ?></td>
        
                    <!-- Capitalize status -->
                    <td><?php echo e(ucfirst($travel->status)); ?></td>
                    <td>
                        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editTravelModal<?php echo e($travel->id); ?>">Process</button>
                        <a href="<?php echo e(route('travel.pdf', $travel->id)); ?>" class="btn btn-secondary btn-sm" target="_blank">View PDF</a>

                        
                    </td>
                </tr>

                <!-- Edit Travel Modal -->
                <div class="modal fade" id="editTravelModal<?php echo e($travel->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editTravelModalLabel<?php echo e($travel->id); ?>" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editTravelModalLabel<?php echo e($travel->id); ?>">Edit Travel Application</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('admin.travel.update', $travel->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                
                                    <!-- Official Station (Employee Input) -->
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5>Official Station</h5>
                                            <p><?php echo e($travel->official_station ?? 'Missing'); ?></p>
                                        </div>
                                    </div>
                                
                                    <!-- Departure Date (Employee Input) -->
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5>Departure Date</h5>
                                            <p><?php echo e($travel->departure_date ?? 'Missing'); ?></p>
                                        </div>
                                    </div>
                                
                                    <!-- Return Date (Employee Input) -->
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5>Return Date</h5>
                                            <p><?php echo e($travel->return_date ?? 'Missing'); ?></p>
                                        </div>
                                    </div>
                                
                                    <!-- Destination (Employee Input) -->
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5>Destination</h5>
                                            <p><?php echo e($travel->destination ?? 'Missing'); ?></p>
                                        </div>
                                    </div>
                                
                                    <!-- Specific Purpose (Employee Input) -->
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5>Specific Purpose</h5>
                                            <p><?php echo e($travel->specific_purpose ?? 'Missing'); ?></p>
                                        </div>
                                    </div>
                                
                                    <!-- Objectives (Employee Input) -->
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5>Objectives</h5>
                                            <p><?php echo e($travel->objectives ?? 'Missing'); ?></p>
                                        </div>
                                    </div>
                                
                                    <!-- Per Diem Expenses (Employee Input) -->
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5>Per Diem Expenses</h5>
                                            <p><?php echo e($travel->per_diem_expenses ?? 'Missing'); ?></p>
                                        </div>
                                    </div>
                                
                                    <!-- Assistant/Laborers Allowed (Employee Input) -->
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5>Assistant or Laborers Allowed</h5>
                                            <p><?php echo e($travel->assistant_or_laborers_allowed ? 'Yes' : 'No'); ?></p>
                                        </div>
                                    </div>
                                
                                    <!-- Appropriation to Which Travel Should Be Charged (Employee Input) -->
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5>Appropriation to Which Travel Should Be Charged</h5>
                                            <p><?php echo e($travel->appropriation_to_which_travel ?? 'Missing'); ?></p>
                                        </div>
                                    </div>
                                
                                    <!-- Remarks or Special Instructions (Employee Input) -->
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5>Remarks or Special Instructions</h5>
                                            <p><?php echo e($travel->remarks_or_special_instructions ?? 'Missing'); ?></p>
                                        </div>
                                    </div>
                                
                                    <!-- Recommending Approval (HR Input) -->
                                    <div class="form-group">
                                        <label for="recommending_approval">Recommending Approval</label>
                                        <input type="text" class="form-control" name="recommending_approval" value="<?php echo e($travel->recommending_approval); ?>">
                                    </div>
                                
                                    <!-- Approved By (HR Input) -->
                                    <div class="form-group">
                                        <label for="approved_by">Approved By</label>
                                        <input type="text" class="form-control" name="approved_by" value="<?php echo e($travel->approved_by); ?>">
                                    </div>
                                
                                   
                                
                                    <!-- Place Signed (HR Input) -->
                                    <div class="form-group">
                                        <label for="place_signed">Place Signed</label>
                                        <input type="text" class="form-control" name="place_signed" value="<?php echo e($travel->place_signed); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="immediate_supervisor">Immidiate Supervisor</label>
                                        <input type="text" class="form-control" name="immediate_supervisor" value="<?php echo e($travel->immediate_supervisor); ?>">
                                    </div>
                                
                                    <!-- Document Number (HR Input) -->
                                    <div class="form-group">
                                        <label for="document_number">Document Number</label>
                                        <input type="text" class="form-control" name="document_number" value="<?php echo e($travel->document_number); ?>">
                                    </div>
                                
                                    <!-- Revision Number (HR Input) -->
                                    <div class="form-group">
                                        <label for="revision_number">Revision Number</label>
                                        <input type="number" class="form-control" name="revision_number" value="<?php echo e($travel->revision_number); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="should_be_charged">Should be Charged</label>
                                        <input type="text" class="form-control" name="should_be_charged" value="<?php echo e($travel->should_be_charged); ?>">
                                    </div>
                                
                                    <!-- Issued Date (HR Input) -->
                                    <div class="form-group">
                                        <label for="issued_date">Issued Date</label>
                                        <input type="date" class="form-control" name="issued_date" value="<?php echo e($travel->issued_date); ?>">
                                    </div>
                                    <!-- Additional Date (HR Input) -->
<div class="form-group">
    <label for="additional_date">Additional Date</label>
    <input type="date" class="form-control" name="additional_date" value="<?php echo e($travel->additional_date); ?>">
</div>

<!-- Travel Number (HR Input) -->
<div class="form-group">
    <label for="travel_number">Travel Number</label>
    <input type="number" class="form-control" name="travel_number" value="<?php echo e($travel->travel_number); ?>">
</div>

                                 <!-- Status (HR Input) -->
                                 <div class="form-group">
                                    <label for="status">Status</label>
                                    <select class="form-control" name="status" required>
                                        <option value="Pending" <?php echo e($travel->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                        <option value="Approved" <?php echo e($travel->status == 'approved' ? 'selected' : ''); ?>>Approved</option>
                                        <option value="Disaproved" <?php echo e($travel->status == 'denied' ? 'selected' : ''); ?>>Denied</option>
                                    </select>
                                </div>
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </form>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
</section>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/admin/travel.blade.php ENDPATH**/ ?>