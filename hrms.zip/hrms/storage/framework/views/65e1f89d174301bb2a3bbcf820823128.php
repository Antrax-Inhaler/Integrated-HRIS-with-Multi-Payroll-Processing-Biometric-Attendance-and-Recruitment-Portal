<?php echo $__env->make('applicant.psdtopbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>References</h1>

<!-- Form to add or edit reference entries -->
<form action="<?php echo e(isset($editReference) ? route('applicant.references.update', $editReference->id) : route('applicant.references.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(isset($editReference)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <!-- Reference Name Input -->
    <div class="form-group">
        <label for="reference_name">Name:</label>
        <input type="text" name="reference_name" value="<?php echo e($editReference->reference_name ?? ''); ?>" required>
    </div>

    <!-- Reference Address Input -->
    <div class="form-group">
        <label for="reference_address">Address:</label>
        <input type="text" name="reference_address" value="<?php echo e($editReference->reference_address ?? ''); ?>" required>
    </div>

    <!-- Reference Telephone Input -->
    <div class="form-group">
        <label for="reference_telephone">Telephone:</label>
        <input type="text" name="reference_telephone" value="<?php echo e($editReference->reference_telephone ?? ''); ?>" required>
    </div>

    <!-- Submit Button -->
    <div class="form-group">
        <button class="submit-button" type="submit"><?php echo e(isset($editReference) ? 'Update' : 'Add'); ?></button>
    </div>
</form>

<!-- Table of existing reference entries -->
<table border="1">
    <thead>
        <tr>
            <th>Name</th>
            <th>Address</th>
            <th>Telephone</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pdsReferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($reference->reference_name); ?></td>
                <td><?php echo e($reference->reference_address); ?></td>
                <td><?php echo e($reference->reference_telephone); ?></td>
                <td>
                    <!-- Edit Button -->
                    <a href="<?php echo e(route('applicant.references', ['edit' => $reference->id])); ?>" class="update-button"><i class="fas fa-edit"></i></a>

                    <!-- Delete Button -->
                    <form action="<?php echo e(route('applicant.references.delete', $reference->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="delete-button"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>



<!-- Navigation Buttons -->
<div class="navigation-buttons">
    <button id="back-button" class="nav-button" onclick="goBack()">Back</button>
    <button id="next-button" class="nav-button" onclick="goNext()">Next</button>
</div>

<!-- Navigation Scripts -->
<script>
    function goBack() {
        // Navigate to the specified back URL
        window.location.href = '/applicant/referencespds'; // Replace with the actual URL
    }
    
    function goNext() {
        // Navigate to the specified next URL
        window.location.href = '/applicant/legal-questionnaire'; // Replace with the actual URL
    }
</script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/applicant/references.blade.php ENDPATH**/ ?>